import React, { useState } from "react";
import { ethers } from "ethers";
import SicboABI from "../abi/Sicbo.json";

const CONTRACT_ADDRESS = "0xYourContractAddress";

function App() {
  const [betType, setBetType] = useState("big");
  const [message, setMessage] = useState("");

  const placeBet = async () => {
    try {
      if (!window.ethereum) return alert("Install MetaMask for Monad Testnet");
      await window.ethereum.request({ method: "eth_requestAccounts" });

      const provider = new ethers.BrowserProvider(window.ethereum);
      const signer = await provider.getSigner();
      const contract = new ethers.Contract(CONTRACT_ADDRESS, SicboABI, signer);

      const tx = await contract.placeBet(betType, {
        value: ethers.parseEther("0.01"),
      });

      setMessage("Waiting for confirmation...");
      await tx.wait();
      setMessage("Bet placed successfully!");
    } catch (err) {
      console.error(err);
      setMessage("Transaction failed: " + err.message);
    }
  };

  return (
    <div className="App">
      <h1>Sicbo Game (Monad Testnet)</h1>
      <select value={betType} onChange={(e) => setBetType(e.target.value)}>
        <option value="big">Big (11-17)</option>
        <option value="small">Small (4-10)</option>
      </select>
      <button onClick={placeBet}>Bet 0.01 MON</button>
      <p>{message}</p>
    </div>
  );
}

export default App;
